model.users.findOne({ email: email }).then((user) => {
  if (user) {
    msgArr.push({ type: "danger", msg: "Email already registered!" });
    res.render("register", { msg: msgArr, layout: false });
  } else {
    bcrypt.genSalt(10, (err, salt) => {
      bcrypt.hash(req.body.password, salt, async (err, hash) => {
        const thisUser = new model.users({
          name: req.body.name,
          email: req.body.email,
          password: hash,
        });

        const rc = await thisUser.save();
        console.log(rc);
        msgArr.push({ type: "success", msg: "You are registered! Now you can log in." });
        req.flash("msg", msgArr);
        res.redirect("/login");
      });
    });
  }
});
